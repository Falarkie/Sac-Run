package com.csus.csc133;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.*;
import com.codename1.ui.Transform.NotInvertibleException;
import com.codename1.ui.geom.Shape;
import com.codename1.ui.plaf.Border;

import gameObjects.GameObject;
import gameObjects.GameObjectCollection;
import gameObjects.LectureHall;
import gameObjects.RestRoom;
import gameObjects.Student;
import gameObjects.StudentPlayer;
import gameObjects.WaterDispenser;


//Center  GUI
public class ViewMap extends Container implements Observer{
	private GameModel gm;
	private SacRun form;
	private int selected = -4; //-4 = nothing, -3 = player, -2 = strat1, -1 = strat2, 0, 1, 2... = corresponding item in gameObjs of that index
	private boolean change = false;
	//private int hm = 0;
	//private boolean itemSelected;
	//private ArrayList<Shape> drawObjs = new ArrayList<Shape>();
	
	int sW, sH;
	int vL = 0;
	int vB = 0;
	int vW = 1024;
	int vH = 768;
	
	int ogVW;
	int ogVH;
	
	Transform VTM = Transform.makeIdentity();
	Transform W2ND = Transform.makeIdentity();
	Transform ND2D = Transform.makeIdentity();
	Transform invVTM = Transform.makeIdentity();
	
	private int pointerX = 0;
	private int pointerY = 0;
	private boolean pinch = false;
	private boolean drag = false;
	
	public ViewMap(GameModel gm, SacRun form) {
		this.gm = gm;
		this.form = form;
		//getAllStyles().setBorder(Border.createLineBorder(1,ColorUtil.rgb(255, 0, 0)));
		getAllStyles().setBgColor(ColorUtil.rgb(200, 200, 200));
		
		//add(new Label("Center/View Map"));
	}
	
	public void init() {
		ogVW = vW = sW = this.getWidth();
		ogVH = vH = sH = this.getHeight();
		updateVTM();
	}
	
	public void updateVTM() {
		VTM = Transform.makeIdentity();
		
		W2ND = Transform.makeScale(1.0f/vW, 1.0f/vH);
		W2ND.translate(-vL, -vB);
		
		ND2D = Transform.makeTranslation(0, sH);
		ND2D.scale(sW, -sH);
		
		VTM.concatenate(ND2D);
		VTM.concatenate(W2ND);
		
		//get the inverse too
		try {
			VTM.getInverse(invVTM);
		} catch(NotInvertibleException e) {
			
		}
	}
	
	public void pointerPressed  (int x,int y){ 
		int thisX = (int)( x );
		int thisY = (int)(y + this.getAbsoluteY());
		pointerX = x;
		pointerY = y;
		form.pressed(thisX,thisY); 
		//When pressed do an AABB collision check with all items
		if(change) {
			change = false;
			float[] pts = {thisX- this.getAbsoluteX(), y - this.getAbsoluteY()};
			invVTM.transformPoint(pts, pts);
			
			int newX = (int)pts[0];
			int newY = (int)pts[1];
			
			
			form.moveItem(newX,newY, selected);
		}
		else {	
			//Check if player was clicked
			selected = -4;
			if(mouseClickOnObj(gm.getPlayer(), thisX, thisY)) {
				//System.out.println("Player Selected");
				selected = -3;
			}
			if(mouseClickOnObj(gm.getStrat1(), thisX,thisY)) {
				selected = -2;
			}
			if(mouseClickOnObj(gm.getStrat2(), thisX,thisY)) {
				selected = -1;
			}
			GameObjectCollection handle = gm.getCol();
			for(int i = 0; i < gm.getCol().size(); i++) {
				if(mouseClickOnObj(handle.get(i), thisX,thisY)) {
					selected = i;
				}
			}
		}
		repaint();
	}
	
	public int selectedItem() {
		return selected;
	}
	
	public void awaitClick() {
		change = true;
	}
	
	private boolean mouseClickOnObj(GameObject obj, int x, int y) {
		if(obj.contain(x, y)) {
			return true;
		}
		return false;
	}

	@Override
	
	public void paint(Graphics g) {
		super.paint(g);
		Transform xform = Transform.makeIdentity();
		xform.translate(getX(), 2*this.getAbsoluteY());
		
		updateVTM();
		xform.concatenate(VTM);

		g.setTransform(xform);
		//Test Drawing box
		g.setColor(ColorUtil.BLACK);
		g.drawRect(0, 0, this.getWidth()-1, this.getHeight()-1);
		
		//Draw Player
		if(selected == -3)
			gm.getPlayer().draw(g, this.getAbsoluteX(), this.getAbsoluteY(), true);
		else
			gm.getPlayer().draw(g, this.getAbsoluteX(), this.getAbsoluteY(), false);
		//Draw Strat 1
		if(selected == -2) 
			gm.getStrat1().draw(g, this.getAbsoluteX(), this.getAbsoluteY(), true);
		else
			gm.getStrat1().draw(g, this.getAbsoluteX(), this.getAbsoluteY(),false);
		//Draw Strat 2
		if(selected == -1)
			gm.getStrat2().draw(g, this.getAbsoluteX(), this.getAbsoluteY(), true);
		else
			gm.getStrat2().draw(g, this.getAbsoluteX(), this.getAbsoluteY(), false);
	
		GameObjectCollection handle = gm.getCol();
		handle.reset();
		GameObject item;
		int i = 0;
		while(handle.hasNext()) {
			item = (GameObject)handle.getNext();
			//Draw each other obj
			if(selected == i)
				item.draw(g, this.getAbsoluteX(), this.getAbsoluteY(), true);
			else
				item.draw(g, this.getAbsoluteX(), this.getAbsoluteY(), false);
			i++;
		}
		//System.out.println("Displaying objects");	
		g.resetAffine();
		
	}
	
	@Override
	public void update(Observable gameModel, Object data) {
		// TODO Auto-generated method stub
		this.gm = (GameModel) gameModel;
		//System.out.println("Map updated");
		//System.out.println(gm.getPlayer().getHead());
		repaint();
	}
	
	//Handle Scrolling
	public void pointerReleased(int x, int y) {
		if(pinch || drag) {
			drag = false;
			pinch = false;
		}
	}
	public void pointerDragged(int x, int y) {
		drag = true;
		double dx = pointerX - x;
		double dy = pointerY - y;
		
		dx *= (vW/(float)sW);
		dy *= -(vH/(float)sH);
		
		panH(dx);
		panV(dy);
		
		pointerX = x;
		pointerY = y;
	}
	
	public void panH(double x) {
		vL += x;
		this.repaint();
	}
	public void panV(double y) {
		vB += y;
		this.repaint();
	}
	
	//Handle zooming
	public boolean pinch(float scale) {
		pinch = true;
		super.pinch(scale);
		zoom(scale);
		return true;
	}
	public void zoom(float scale) {
		float newW = vW * (scale);
		float newH = vH * (scale);
		
		if(newW < 400 || newH < 300 || newW > 8192 || newH > 4320) return;
		
		vL += (vW - newW)/2;
		vB += (vH - newH)/2;
		
		vW = (int) newW;
		vH = (int) newH;
		
		this.repaint();
	}
	
	

}
