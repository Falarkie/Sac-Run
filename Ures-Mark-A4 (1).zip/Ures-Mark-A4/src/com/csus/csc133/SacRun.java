/*
* This file is the skeleton code of SacRun for the CSC133 assignment at the 
* Computer Science Department of California State University,
* Sacramento. Note that the CSC133 assignments are confidential and 
* copyrighted. It is not allowed to publish any CSC133 source code 
* to the public. Any existing source code for CSC133 assignments on the   
* internet represents that this student did/will disclose confidential  
* materials to the public and violate the designer's copyright.
*
*/

package com.csus.csc133;

import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.*;
import com.codename1.ui.events.*;
import com.codename1.ui.layouts.*;
import com.codename1.ui.util.UITimer;

import gameObjects.GameObject;
import gameObjects.GameObjectCollection;
import gameObjects.StudentPlayer;
import gameObjects.StudentStrategy;

public class SacRun extends Form implements Runnable{
	
	private GameModel gm;
	boolean a2Done = false;
	private boolean playerMove = false;
	private StudentPlayer handlePlayer;
	private ViewMap vMap;
	private Container vStat;
	private Container vMessage;
	private Container vButtons;
	private Toolbar tool;
	private Random rand = new Random(System.currentTimeMillis());
	UITimer timer;
	int frame = 20;
	//Command lists
	private PlayerCommands[] pCom = new PlayerCommands[5];
	private WorldCommands[] wCom = new WorldCommands[6];
	
	private int musVol = 10;
	private int checkCount = 0;
	private boolean checking = false;
	
	char currentKey;
	boolean keyPress = false;
	boolean gamePaused = false;
	
	private Sound bgMusic;
	private int musCheckCount = 0;
	private boolean check = false;;
	//Label label = new Label();
	
	
	
	public SacRun(){
		gm = new GameModel(frame);

		A2();
		//get the program stuck until the gui loads to prevent the width and height from being 0 when attempting to generate the objects
		//they will give an error as trying to place them in coordiates when the maximums are 0 causes errors
		while(!a2Done)	{
			//do nothing wait until GUI loads
		}
		gm.setBounds(vMap.getWidth(), vMap.getHeight());
		//System.out.println("Init gm with bounds X:" + vMap.getWidth() + "Y: " + vMap.getHeight());
		vMap.init();
		gm.init();
		
		bgMusic = new Sound("georgiabrown.wav", true);
		bgMusic.load();
		
		timer = new UITimer(this);
		timer.schedule(frame, true, this);
		
		bgMusic.setVol(musVol);
		bgMusic.play();
	}
	
	//UI provided for A1 only, remove it in A2
	/*private void A1() {
		Label myLabel=new Label("Enter a Command:");
		TextField myTextField=new TextField();
		this.add(myLabel).add(myTextField);
		this.show();
		myTextField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt) {
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
				if(sCommand.isEmpty()) return;
				handleInput(sCommand.charAt(0));
			}
		});
	}*/
	
	private void A2() {
		//Initialize Commands
		createCommands();
		//Creating the main UI
		

		vStat = new ViewStatus();
		vMessage = new ViewMessage();
		vButtons = new ViewButtons(pCom,wCom);
		vMap = new ViewMap(gm, this);
		setLayout(new BorderLayout());
		gm.addObserver((Observer) vStat);
		gm.addObserver((Observer) vMessage);
		gm.addObserver((Observer) vMap);
		gm.setBounds(vMap.getWidth(), vMap.getHeight());
		
		
		add(BorderLayout.EAST, vStat);
		add(BorderLayout.WEST, vButtons);
		add(BorderLayout.CENTER, vMap);
		add(BorderLayout.SOUTH, vMessage);
		
		
		
		createToolbar();
		this.show();
		a2Done = true;
		//gm.simulateChange();
	}

	private void createCommands() {
		// TODO initialize the commands
		pCom[0] = new PlayerCommands("Move", this);
		pCom[1] = new PlayerCommands("Stop", this);
		pCom[2] = new PlayerCommands("Left", this);
		pCom[3] = new PlayerCommands("Right", this);
		pCom[4] = new PlayerCommands("Change Strategy", this);
		
		/*
		wCom[0] = new WorldCommands("Lecture Hall", this);
		wCom[1] = new WorldCommands("Restroom", this);
		wCom[2] = new WorldCommands("Water Dispenser", this);
		wCom[3] = new WorldCommands("Student", this);
		wCom[4] = new WorldCommands("Next Frame", this);
		*/
		wCom[0] = new WorldCommands("Play", this);
		wCom[1] = new WorldCommands("Pause", this);
		wCom[2] = new WorldCommands("Change Location", this);
		wCom[3] = new WorldCommands("About", this);
		wCom[4] = new WorldCommands("Music Volume", this);
		wCom[5] = new WorldCommands("Exit", this);
	}
	private void createToolbar() {
	//Create the toolbar
			tool = new Toolbar();
			setToolbar(tool);
			
			tool.addCommandToSideMenu(pCom[4]);
			tool.addCommandToSideMenu(wCom[2]);
			tool.addCommandToSideMenu(wCom[3]);
			
			tool.addCommandToRightBar(wCom[3]);
			tool.addCommandToRightBar(wCom[2]);
			
	}
	
	//Below are the functions used to make the player commands of buttons work
	public void move() {
		//System.out.println("Player moving");
		updateCommandCode(1);
		playerMove = true;
		//Makes movement begin
	}
	
	public void stop() {
		//System.out.println("Player stopped");
		playerMove = false;
		updateCommandCode(2);
		//Makes movement stop
	}
	
	public void left() {
		//System.out.println("Player turned left");
		handlePlayer = StudentPlayer.getPlayer(gm);
		handlePlayer.Turn(0, 0);
		gm.setPlayer(handlePlayer);
		updateCommandCode(3);
		//turn left
	}
	
	public void right() {
		//System.out.println("Player Turned right");
		handlePlayer = StudentPlayer.getPlayer(gm);
		handlePlayer.Turn(1, 0);
		gm.setPlayer(handlePlayer);
		updateCommandCode(4);
		//turn right
	}
	
	public void changeStrat() {
		StudentStrategy handle1 = gm.getStrat1();
		StudentStrategy handle2 = gm.getStrat2();
		
		int randomint = rand.nextInt(3);
		handle1.setStrategy(randomint);
		randomint = rand.nextInt(3);
		handle2.setStrategy(randomint);
		
		gm.setStrat1(handle1);
		gm.setStrat2(handle2);
		//System.out.println("hm");
		updateCommandCode(5);
	}
	
	
	/*
	public void lectureHall() {
		//gm.simFirstLectComplete();
		updateCommandCode(6);
	}
	
	public void restroom() {
		handlePlayer = StudentPlayer.getPlayer(gm);
		handlePlayer.restRoom();
		//gm.setPlayer(handlePlayer);
		updateCommandCode(7);
	}
	
	public void waterDispenser() {
		handlePlayer = StudentPlayer.getPlayer(gm);
		handlePlayer.drinkWater();
		gm.setPlayer(handlePlayer);
		//TODO:Simulate player-water col
		updateCommandCode(8);
	}
	
	public void student() {
		//creates a dialog box with text field, the user can let the player interact with a student of the desired number
		//0 = angry, 1 = bike, 2 = car, 3 = conf, 4 = friend, 5 = happy, 6 = nonstop, 7 = sleeping, 8 = run, 9 = strat
		boolean inputValid = false;
		Command confirm = new Command("Confirm");
		int value;
		TextField myTextField = new TextField();
		while(!inputValid) {
			myTextField = new TextField();
			Command studentBox = Dialog.show("What Student type?", myTextField, confirm);

			try {
				value = Integer.parseInt(myTextField.getText());
				if(value >=0 && value <= 9) {
					inputValid = true;
				}
				else {
					Command error = Dialog.show("Input invalid", myTextField.getText()+" is not valid input", confirm);
				}
			}catch(Exception e) {
				Command error = Dialog.show("Input invalid", myTextField.getText()+" is not valid input", confirm);
			}
		}
		value = Integer.parseInt(myTextField.getText());
		//gm.collideStudent(value);
		
		updateCommandCode(9);
	}
	*/
	
	public void nextFrame() {
		//System.out.println("Frame++");
		//handlePlayer = gm.getPlayer();
		handlePlayer = StudentPlayer.getPlayer(gm);
		
		if(playerMove) {
			handlePlayer.studentMove(gm.getWidth(),gm.getHeight(),frame);
		}
		handlePlayer.incTime(frame);
		gm.setPlayer(handlePlayer);
		gm.incTime();
		//updateCommandCode(10);
		
		//These ensure the gameModel stays updated with where the vMap is and how large it is
		gm.setBounds(vMap.getWidth(), vMap.getHeight());
	}
	//Below are the functions used to make the world commands of buttons work
	
	public void pause() {
		bgMusic.stop();
		gamePaused = true;
		timer.cancel();
		((ViewButtons) vButtons).paused(wCom);
		//this.show();
	}
	
	public void play() {
		bgMusic.play();
		gamePaused = false;
		timer.schedule(frame, true, this);
		((ViewButtons) vButtons).unpause(wCom);
		//this.show();
	}
	
	public void changeLocation() {
		int item = ((ViewMap) vMap).selectedItem();
		if(item != -4) {
			((ViewMap) vMap).awaitClick();
		}
		else {
			Command confirmBox = new Command("Okay");
			Command abtBox = Dialog.show("Error","Object must be selected to use change location", confirmBox);
		}
	}
	
	public void about() {
		//
		Command confirmBox = new Command("Confirm");
		Command abtBox = Dialog.show("A4", "Mark Ures Spring 2024", confirmBox);
		updateCommandCode(11);
	}
	
	public void exit() {
		updateCommandCode(12);
		Boolean exitBox = Dialog.show("Exit", "Are you sure you would like to exit?", "Yes", "No");
		if(exitBox) {
			CN.exitApplication();
		}
		
	}
	
	
	
	public boolean getGameStatus() {
		return gm.isGameRunning();
	}
	
	public void updateCommandCode(int num) {
		gm.setCommandCode(num);
	}
	
	public void gameOver() {
		gm.endGame("");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(!gamePaused) {
			nextFrame();
			if(keyPress) {
				//System.out.println(currentKey);
				switch(currentKey){
				case 'w': 
				case 'W':
					move();
					break;
				case 's':
				case 'S':
					stop();
					break;
				case 'a':
				case 'A':
					left();
					break;
				case 'd':
				case 'D':
					right();
					break;
				}
			}
		}
		
	}
	

	public void keyPressed  (int keyCode ) { 
		//System.out.println((char)keyCode + " Pressed");
		currentKey = (char)keyCode;
		keyPress = true;
	}
	
	public void	keyReleased (int keyCode ) {
		//System.out.println((char)keyCode + " Released");
		keyPress = false;
	}
	
	public void pressed(int x, int y) {
		//System.out.println("click at X:" + x + " Y:"+ y );
	}

	public void moveItem(int thisX, int thisY, int selected) {
		// TODO Auto-generated method stub
		GameObject handle;
		if(selected == -3) {
			handle = gm.getPlayer();
			handle.setLocalX(thisX);
			handle.setLocalY(thisY);
			
			gm.setPlayer((StudentPlayer) handle);
		}
		else if(selected == -2) {
			handle = gm.getStrat1();
			handle.setLocalX(thisX);
			handle.setLocalY(thisY);
			
			gm.setStrat1((StudentStrategy)handle);
		}
		else if(selected == -1) {
			handle = gm.getStrat2();
			handle.setLocalX(thisX);
			handle.setLocalY(thisY);
			
			gm.setStrat2((StudentStrategy)handle);
		}
		else if(selected >= 0) {
			handle = gm.getCol().get(selected);
			handle.setLocalX(thisX);
			handle.setLocalY(thisY);
			
			gm.placeAt(selected, handle);
			
			
		}
	}
	
	public void volume() {
		boolean inputValid = false;
		Command confirm = new Command("Confirm");
		int value;
		TextField myTextField = new TextField();
		while(!inputValid) {
			myTextField = new TextField();
			Command studentBox = Dialog.show("What would you like the % volume to be (Note: default is 10%)?", myTextField, confirm);

			try {
				value = Integer.parseInt(myTextField.getText());
				if(value >=0 && value <= 100) {
					inputValid = true;
				}
				else {
					Command error = Dialog.show("Input invalid", myTextField.getText()+" is not valid input", confirm);
				}
			}catch(Exception e) {
				Command error = Dialog.show("Input invalid", myTextField.getText()+" is not valid input", confirm);
			}
		}
		value = Integer.parseInt(myTextField.getText());
		musVol = value;
		bgMusic.setVol(musVol);
	}
}

