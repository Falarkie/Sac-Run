package com.csus.csc133;

import java.io.InputStream;
import java.util.Timer;

import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;
import com.codename1.ui.util.UITimer;

import javafx.scene.media.MediaPlayer;

public class Sound implements Runnable{
	private Media m;
	private boolean looped = false;
	private boolean isEnded = true;
	private String file;
	private boolean loaded = false;
	
	public Sound(String fileName, boolean looped) {
		this.looped = looped;
		file = fileName;
		
	}
	
	//Takes durration in seconds
	public void load() {
		try {
			InputStream is = Display.getInstance().getResourceAsStream(getClass(), "/" + file);
			m = MediaManager.createMedia(is, "audio/wav", this);
			loaded = true;
			System.out.println("Loaded sound: "+ file +  " successfully Duration: " + m.getDuration() );
		} catch(Exception err) {
			err.printStackTrace();
		}
		//this.duration = time*1000;
	}
	
	public void play() {
		if(m == null) return;
		m.play();
	}
	
	public void startPlay() {
		m.setTime(0);
		m.play();
	}
	public void stop() {
		if(m == null) return;
		m.pause();
	}

	@Override
	public void run() {
		if(m == null) return;
		System.out.print("Done");
		if(looped) {
			startPlay();
		}
	}
	
	public void setVol(int val) {
		if(m == null) return;
		m.setVolume(val);
	}
	
	
	

}
